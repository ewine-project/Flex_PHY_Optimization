function [gfdm,ofdm] = config_gfdm_dynamic_spectrum_access(BW, Avail_Spectrum, Guard_BW, subcarriers, subsymbols)
%BW             = 20*1e6;
PSD_plotrange  = [-40 40]*1e6;
%Avail_Spectrum = [-7*1e6 -5*1e6; 3*1e6 4*1e6];   % in Hz, a matrix of two columns and multiple rows. Each row is associated to a consecutive spectrum specified by the start freq idx and end freq idx 
%Guard_BW       = 5*1e4;                          % in Hz, put a guard band on the boundary of the avail_spectrum

%% OFDM configuration
ofdm.Sampfreq = BW;                              % in Hz
ofdm.Ts       = 1/ofdm.Sampfreq;                 % Sampling period in second
ofdm.K        = subcarriers;                              % Number of total subcarriers
ofdm.fs       = ofdm.Sampfreq/ofdm.K;            % Subcarrier spacing in Hz
ofdm.Tsym     = 1/ofdm.fs;                       % Symbol duration in second (without CP, CS)
ofdm.Nr_cp    = round(ofdm.K/4);                 % Numberof samples in the CP part
ofdm.Tcp      = ofdm.Nr_cp/ofdm.Sampfreq;        % CP length in second
%%% general comments: %%%
% 1) BW represents the bandwidth of the spectrum open for
% dynamic spectrum access. Here, we assume the center frequency is located
% at the middle of the spectrum, i.e., DC in baseband. 
% 2) The number K of total subcarriers is a parameter depending on the
% capability of the PHY implementation. For a given BW, the value of K
% decides the subcarrier spacing and therefore also the symbol duration
% under the critical sampling assumption. If you want to have short symbol
% duration, please choose a small K.
%%%

%% For select the active subcarriers, we build a freq_bin, subcarrier map, namely, the subcarrier occupies which frequeny bins
ofdm.fbin_vec     = -ceil((ofdm.K-1)/2)*ofdm.fs:ofdm.fs:floor((ofdm.K-1)/2)*ofdm.fs; %the list of frequency bins
ofdm.Sub_freqmap  = eye(ofdm.K);
ofdm.fbin_flg     = zeros(length(ofdm.fbin_vec),1);
for k = 1:size(Avail_Spectrum,1)
   ofdm.fbin_flg(and(ofdm.fbin_vec > Avail_Spectrum(k,1)+Guard_BW+ofdm.fs/2, ofdm.fbin_vec < Avail_Spectrum(k,2)-Guard_BW-ofdm.fs/2) == 1) = 1;
end
tmp                   = repmat(ofdm.fbin_flg,1,ofdm.K).*ofdm.Sub_freqmap;
tmp_idx               = -ceil((ofdm.K-1)/2) : floor((ofdm.K-1)/2);
ofdm.Kon_idx          = tmp_idx(sum(tmp,1) == 1);
[psd_ofdm,ofdm_f_bin] = gen_psd_ofdm(ofdm,PSD_plotrange);
ofdm.sym_rate         = length(ofdm.Kon_idx)/(ofdm.Tsym + ofdm.Tcp); % nr. of data symbols (e.g., QAM) per second

%% GFDM specific configuration     
gfdm.Sampfreq  = ofdm.Sampfreq;            % The same target spectrum, the same sampling freq
gfdm.flt_type  = 'RC';                     % sorry, here I only support RC filter :)
gfdm.a         = 0.5;                      % roll-off factor
gfdm.M         = subsymbols;               % Number of subsymbols per GFDM symbol
gfdm.Mon_idx   = 2:(gfdm.M-1);             % Not using the first and last subsymbol for nice OOB performance
gfdm.K         = ofdm.K;                   % Number of subcarriers per GFDM symbol
gfdm.N         = gfdm.M*gfdm.K;            % Number of samples per GFDM symbol
gfdm.fs        = gfdm.Sampfreq/gfdm.K;     % subcarrier spacing of GFDM in Hz
gfdm.Tsubsym   = 1/gfdm.fs;                % subsymbol spacing in second
gfdm.fbin      = gfdm.fs/gfdm.M;           % spectral spacing (Hz) of two adjacent frequency bins, i.e., frequency resolution of GFDM
gfdm.Tsym      = gfdm.Tsubsym * gfdm.M;    % GFDM symbol duration in second (without CP, CS)

gfdm.Mon       = length(gfdm.Mon_idx);     % Number of subsymbols for data transmission.
gfdm.Nr_cp     = 0;                        % CP length normalized by the sampling period. 
gfdm.Tcp       = gfdm.Nr_cp/gfdm.Sampfreq; % CP length in second
gfdm           = gen_gfdm_flt(gfdm);       % Note, the pulse shaping filter is normalized to have energy 1 in continuous-time model
                                           % So, sum(abs(gfdm.g_pulse).^2)) = gfdm.Sampfreq in discrete-time model
                                           

%% For select the active subcarriers, we build a freq_bin, subcarrier map, namely, the subcarrier occupies which frequeny bins
gfdm.fbin_vec     = (-ceil((gfdm.K-1)/2)*gfdm.fs-gfdm.lhs_range*gfdm.fbin):gfdm.fbin: (floor((gfdm.K-1)/2)*gfdm.fs+gfdm.rhs_range*gfdm.fbin); %the list of frequency bins
gfdm.Sub_freqmap  = zeros(length(gfdm.fbin_vec),gfdm.K); 
for k =  -ceil((gfdm.K-1)/2) : floor((gfdm.K-1)/2)
    sub_k_occupied_fbin = (k*gfdm.M-gfdm.lhs_range):(k*gfdm.M+gfdm.rhs_range);
    gfdm.Sub_freqmap((sub_k_occupied_fbin - (-ceil((gfdm.K-1)/2)*gfdm.M-gfdm.lhs_range))+1,k+ceil((gfdm.K-1)/2)+1) = 1;
end

%% Given Avail_spectrum, let us calculate the subcarriers that can be activated.
gfdm.fbin_flg  = zeros(length(gfdm.fbin_vec),1);
for k = 1:size(Avail_Spectrum,1)
   gfdm.fbin_flg(and(gfdm.fbin_vec > Avail_Spectrum(k,1)+Guard_BW+gfdm.fbin/2, gfdm.fbin_vec < Avail_Spectrum(k,2)-Guard_BW-gfdm.fbin/2) == 1) = 1;
end
%%%% Graphical double check for allocation
%figure
%plot(gfdm.fbin_vec/1e6)
%hold on
%a = 1:length(gfdm.fbin_vec);
%plot(a(gfdm.fbin_flg==1),gfdm.fbin_vec(gfdm.fbin_flg==1)/1e6,'r--x');
% from the y-axis, the red dots represent the active bins, they shall be
% within the available spectrum.
%%%%%%
tmp          = repmat(gfdm.fbin_flg,1,gfdm.K).*gfdm.Sub_freqmap;
tmp_idx      = -ceil((gfdm.K-1)/2) : floor((gfdm.K-1)/2);
gfdm.Kon_idx = tmp_idx(sum(tmp,1) == (gfdm.lhs_range+gfdm.rhs_range+1));
[psd_gfdm,gfdm_f_bin] = gen_psd_gfdm(gfdm,PSD_plotrange);
gfdm.sym_rate  = length(gfdm.Kon_idx)*gfdm.Mon/(gfdm.Tsym + gfdm.Tcp); % nr. of data symbols (e.g., QAM) per second

figure(100);
clf;
plot(gfdm_f_bin/1e6,10*log10(psd_gfdm),'r');
hold on
plot(ofdm_f_bin/1e6,10*log10(psd_ofdm),'b');
mask_freq = [PSD_plotrange(1) kron(reshape(Avail_Spectrum',1,numel(Avail_Spectrum)),ones(1,2)) PSD_plotrange(2)];
mask_dB   = kron([kron(ones(1,size(Avail_Spectrum,1)),[-200 0]),-200],ones(1,2));
plot(mask_freq/1e6,mask_dB,'k','LineWidth',3);
ylim([-200 10]);
xlim(0.6*[-BW BW]./1e6);
legend('PSD of GFDM','PSD of OFDM','Ideal Spectrum Mask');
xlabel('Freq (MHz)');
ylabel('PSD (dB)');
legend('Location','southwest');
hold off;
%keyboard;

% save in variable

gfdm.pl_x = gfdm_f_bin/1e6;
gfdm.pl_y = 10*log10(psd_gfdm);

ofdm.pl_x = ofdm_f_bin/1e6;
ofdm.pl_y = 10*log10(psd_ofdm);

gfdm.pl_mask_x = mask_freq/1e6;
gfdm.pl_mask_y = mask_dB;

end

function [psd_ofdm,f_bin] = gen_psd_ofdm(ofdm,BW_range)
f_bin_rgt = 0:0.04*ofdm.fs:BW_range(2);
f_bin_lft = -0.04*ofdm.fs:-0.04*ofdm.fs:BW_range(1);
f_bin = [f_bin_lft(end:-1:1) f_bin_rgt];
%f_bin    = linspace(BW_range(1),BW_range(2),1e4);
sinc_mtx = sinc(repmat(f_bin',1,length(ofdm.Kon_idx))*(ofdm.Tsym+ofdm.Tcp) - repmat(ofdm.Kon_idx/ofdm.Tsym,length(f_bin),1)*(ofdm.Tsym+ofdm.Tcp));

%here we assume energy per symbol = 1
psd_ofdm = sum(abs(sinc_mtx).^2,2);
end

function [psd_gfdm,f_bin] = gen_psd_gfdm(gfdm,BW_range)
    %f_bin      = linspace(BW_range(1),BW_range(2),5e3);
    f_bin_rgt = 0:0.01*gfdm.fs:BW_range(2);
    f_bin_lft = -0.01*gfdm.fs:-0.01*gfdm.fs:BW_range(1);
    f_bin = [f_bin_lft(end:-1:1) f_bin_rgt];
    freq_mtx   = repmat(f_bin,length(gfdm.Kon_idx),1) - repmat(gfdm.Kon_idx'*gfdm.fs,1,length(f_bin));
    psd_gfdm_d = zeros(1,length(f_bin));   
    for idx1 = -gfdm.lhs_range:gfdm.rhs_range
        for idx2 = -gfdm.lhs_range:gfdm.rhs_range
            for m = 1:length(gfdm.Mon_idx)
                tmp = gfdm.G_v(idx1+gfdm.lhs_range+1)*conj(gfdm.G_v(idx2+gfdm.lhs_range+1))*exp(-1i*2*pi*(gfdm.Mon_idx(m)-1)*(idx1-idx2)/gfdm.M);
                tmp = tmp*gen_spectrum_win(0,gfdm.Tsym,freq_mtx-idx1/gfdm.Tsym);
                tmp = tmp.*conj(gen_spectrum_win(0,gfdm.Tsym,freq_mtx-idx2/gfdm.Tsym));
                psd_gfdm_d = psd_gfdm_d + sum(tmp,1);
            end
        end        
    end
    psd_gfdm = real(psd_gfdm_d)/(gfdm.Tsym+gfdm.Tcp);
end

function spectrum_win = gen_spectrum_win(T_start,T_end,f_bin)
    spectrum_win = exp(-1i*pi*f_bin*(T_start+T_end))*(T_end-T_start).*sinc(f_bin*(T_end-T_start));
end

function gfdm = gen_gfdm_flt(gfdm)
if ~strcmp(gfdm.flt_type,'RC')
    warning('not supported filter type');
end

% Using RC filter as an example
if mod(gfdm.M,2) == 1   
    range    = floor((gfdm.a+1)/2*gfdm.M);
    G_v      = zeros(1,2*range+1);
    for idx = -range:range
        if abs(idx/gfdm.M) <= (1-gfdm.a)/2
            G_v(idx+range+1) =  1;
        elseif abs(idx/gfdm.M) <= (1+gfdm.a)/2
            G_v(idx+range+1) = 0.5*(1+cos(pi/gfdm.a*(abs(idx/gfdm.M)-(1-gfdm.a)/2)));
        end
    end
    gfdm.lhs_range = range;
    gfdm.rhs_range = range;
else % new part for supporting even M
    epsilon = 1e-5; % margin
    gfdm.lhs_range = abs(ceil(epsilon-(gfdm.a+1)/2*gfdm.M-0.5));
    gfdm.rhs_range = floor((gfdm.a+1)/2*gfdm.M-epsilon-0.5);   
    G_v      = zeros(1,gfdm.lhs_range+gfdm.rhs_range+1);
    for idx = -gfdm.lhs_range:gfdm.rhs_range
        if abs(idx/gfdm.M + 1/2/gfdm.M) <= (1-gfdm.a)/2
            G_v(idx+gfdm.lhs_range+1) =  1;
        elseif abs(idx/gfdm.M + 1/2/gfdm.M) <= (1+gfdm.a)/2
            G_v(idx+gfdm.lhs_range+1) = 0.5*(1+cos(pi/gfdm.a*(abs(idx/gfdm.M + 1/2/gfdm.M)-(1-gfdm.a)/2)));
        end
    end
    
end

G_v          = G_v/sqrt(sum(abs(G_v).^2)*gfdm.Tsym);
gfdm.G_v     = G_v; 
gfdm.g_pulse = G_v*exp(1i*2*pi*(-gfdm.lhs_range:gfdm.rhs_range)'/gfdm.Tsym*(0:gfdm.N-1)*gfdm.Tsubsym/gfdm.K); % Note that, here the normalization of the signal energy to one is in the continuous-time domain. Therefore, the sum(abs(g_pulse).^2) = gfdm.BW in discrete time model;
gfdm.g_pulse_norm = gfdm.g_pulse/sqrt(sum(abs(gfdm.g_pulse).^2));
end