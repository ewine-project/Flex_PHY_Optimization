function init_udp(type, id, dll_path)

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %This variable combination is like a unique ip adresse assigned to an %
    %application                                                          %
    %The communication class checks that and assigns a new ID if necessary%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if (~exist('type', 'var')) 
        type = 140;
    end
    if (~exist('id', 'var')) 
        id = 1;
    end
    
    if (~exist('dll_path', 'var')) 
         dll_path = 'C:\sync\global\UDP-Communications.dll';
    end    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Load the DLL into MATLAB     %
    %Enter a LOCAL full path only!%
    %IT IS NOT POSSIBLE TO UN-    %
    %OR RELOAD THE DLL!           %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %if ~isdeployed 
        disp(['Load DLL from ' dll_path]);     
        NET.addAssembly(dll_path);
    %else
    %    NET.addAssembly('UDP-Communications.dll');
    %end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %get the Handle to the Server%
    %and make it global          %
    %IT IS NOT POSSIBLE TO STOP  %
    %THE CALLBACK! (i dont know  %
    %how to do it)               %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    global server 
    
    try
        if (server.udp_active() == 1)
           server.clear_packet_list();
           disp('Server already running... Abort!'); 
           return
        end
    catch
        
    end
    
    server = UDP_Communications.UDP_Server();   

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Init the Communication                                                                         %
    %string ipadress, int port, int ttl, byte type, byte id, [bool wait = false, string filter = ""]%
    %wait = true: Execution is blocked until the initialization is finished.                        %
    %wait = false: The following (Matlab) commands are executed, but before using the server the    %
    %return value of server.initComplete() should be checked.                                       %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    server.init_udp('224.5.6.7', 50000, 1, type, id, true);       

end