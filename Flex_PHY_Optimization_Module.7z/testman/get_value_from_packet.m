function value = get_value_from_packet(packet, variable, varargin)

   %Convert strings into lower case
   content = lower(packet.Content);
   %Look if variable was received in the packet
   pos = strfind(content,variable); 
   
   %Some cell fun...
   empty = cellfun('isempty',pos); 
   pos(empty) = {0}; 
   pos = find([pos{:}] == 1);
   
   %Treat any other input variable as default value, if nothing was
   %received
   if nargin > 0 
       value = varargin{1};
   end
   
   if (~isempty(pos) && (strcmpi(content(pos), variable))) 
      value = str2double(content(pos+1)); 
   end
end