function value = get_vector_from_packet(packet, variable)
   content = lower(packet.Content);
   pos = strfind(content,variable); 
   empty = cellfun('isempty',pos); 
   pos(empty) = {0}; 
   pos = find([pos{:}] == 1);
   value = [];
   if (~isempty(pos) && (strcmpi(content(pos), variable))) 
          content(pos+1) = strrep(content(pos+1), ';', ' ');
          value = textscan(char(content(pos+1)),'%f'); 
          value = value{:};
   end
end