%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TestMan-Wrapper for the GFDM OOB optimization module
% ----------------------------------------------------
%
% UDP wrapper around the function
% config_gfdm_dynamic_spectrum_access(BW, Avail_Spectrum, Guard_BW, subcarriers)
%
% Procedure:
% 1) Receive spectrum mask via the TestMan interface
% 2) Optimize GFDM parameter
% 3) Send parameter back via TestMan
% Loop until [Ctrl] + C or exit via the TestMan
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Where is the DLL?
dll_path = fullfile(cd, 'UDP-Communications.dll');

% Add all libraries
if ~isdeployed 
    addpath(genpath(cd))
end

% Make server class global accessible
global server

% show plots
PLOT = 1;

% use caching from disk to speed up computation
do_caching = 1;

if do_caching
    try
        load('opt_cache.mat')
    catch stmt
        opt_cache = containers.Map();
        save('opt_cache.mat','opt_cache');
    end
else
    % GFDM cache
    opt_cache = containers.Map();    
end

% Initialize TestMan
type = 10;  %application type/class
id = 1;     %application instance number
init_udp(type, id, dll_path);

% Initialize variables
BW             = 20*1e6;
spectrum_mask = [-40*1e6 40*1e6];   % in Hz, a matrix of two columns and multiple rows. Each row is associated to a consecutive spectrum specified by the start freq idx and end freq idx 
Guard_BW       = 5*1e4;  
subcarriers = 64;
subsymbols = 9;

%Who receives the results?
receive_type = 11;
receive_id = 1;

%%%%%%%%%%%%%%
% Main loop
%%%%%%%%%%%%%%

disp('Entering main loop...');
while (1)
   [packet] = receive_packet(1, 1);
   if ~isempty(packet)

       %%%%%%%%%%%%%%%%%%%%%%%%%
       %  Get values from packet
       %%%%%%%%%%%%%%%%%%%%%%%%%
       
       %Bandwidth in [Hz]
       BW = get_value_from_packet(packet, 'bw', BW)
       
       %Number of subcarrier in [Hz]
       subcarriers = get_value_from_packet(packet, 'subcarriers', subcarriers)
       
       %Number of subsymbols
       subsymbols = get_value_from_packet(packet, 'subsymbols', subsymbols)
       
       %Guard Band in [Hz]
       Guard_BW = get_value_from_packet(packet, 'guard_bw', Guard_BW)
       
       %receive_type
       receive_type = get_value_from_packet(packet, 'receive_type', receive_type)
       
       %receive_id
       receive_id = get_value_from_packet(packet, 'receive_id', receive_id)
       
       %Spectrum mask (vector: [start_freq] [stop_freq] ...)  in [Hz]
       value = get_vector_from_packet(packet, 'spectrum_mask')
       if ~isempty(value)
            spectrum_mask = reshape(value, [2, numel(value)/2])'
       end
                
       %Optimize!
       if strcmpi(packet.Command, 'optimize')
           
           cache_key.bw = BW;
           cache_key.subcarriers = subcarriers;
           cache_key.subsymbols = subsymbols;
           cache_key.Guard_BW = Guard_BW;
           cache_key.spectrum_mask = spectrum_mask;
           Opt.Method = 'SHA-1';

           hash_val = DataHash(cache_key, Opt);

           if opt_cache.isKey(hash_val)
               % from cache
               disp('Cache hit');
               res = opt_cache(hash_val);
               gfdm = res.gfdm;
               ofdm = res.ofdm;
               
               if (PLOT)
                    figure(100);
                    clf;
                    plot(gfdm.pl_x, gfdm.pl_y,'r');
                    hold on
                    plot(ofdm.pl_x, ofdm.pl_y,'b');
                    plot(gfdm.pl_mask_x, gfdm.pl_mask_y, 'k','LineWidth',3);
                    ylim([-200 10]);
                    BW = gfdm.Sampfreq;
                    xlim(0.6*[-BW BW]./1e6);
                    legend('PSD of GFDM','PSD of OFDM','Ideal Spectrum Mask');
                    xlabel('Freq (MHz)');
                    ylabel('PSD (dB)');
                    legend('Location','southwest');
                    hold off;                   
               end
           else           
               disp('Cache failed');
               disp('Calculate GFDM parameter...');
               [gfdm,ofdm] = config_gfdm_dynamic_spectrum_access(BW, spectrum_mask, Guard_BW, subcarriers, subsymbols);
               res.gfdm = gfdm;
               res.ofdm = ofdm;
               
               opt_cache(hash_val) = res;
               save('opt_cache.mat','opt_cache');
           end
           
           %Send results to the TestMan network
           fields = fieldnames(gfdm);
           message = '';
           for i=1:numel(fields)
              %send_data(char(fields(i)), num2str(gfdm.(char(fields(i)))));
              try
                %disp(char(fields(i)));
                %send_data('command', 'change', 'parameter', char(fields(i)), 'value',  strjoin(arrayfun(@(x) num2str(x),gfdm.(char(fields(i))),'UniformOutput',false),';'));%, 'type', receive_type, 'id', receive_id);
              catch
                disp(['Could not send information in ' char(fields(i))]); 
              end
           end
           send_data('command', 'change', 'parameter', 'kon_idx', 'value', num2str(gfdm.Kon_idx));%, 'type', receive_type, 'id', receive_id);
           send_data('command', 'change', 'parameter', 'mon_idx', 'value', num2str(gfdm.Mon_idx));%, 'type', receive_type, 'id', receive_id);
           send_data('command', 'update');
           
           [result, return_message] = send_command('command', 'update');%, 'type', receive_type, 'id', receive_id);
           if (result == 0) 
            disp('Could not send update command:');
            disp(return_message);
           end
       end  
       
       if strcmpi(packet.Command, 'exit')
           break;
       end
   end
   pause(0.01);
end

server.stop_udp();