function [ Avail_Spectrum ] = occupy_spectrum( BW, number_of_occupied_parts, guard_band)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
Avail_Spectrum = [];
for i = 1:number_of_occupied_parts
    %Create start_freq
    start_freq = (rand(1) * BW);
    max_freq = (BW - start_freq);
    %Check if this frequency already marked as free
    if ~isempty(Avail_Spectrum)
        while(1)
            index = find(start_freq >= Avail_Spectrum(:,1) - 5*guard_band & start_freq <= Avail_Spectrum(:,2) + guard_band);
            if isempty(index)
                break;
            end
            start_freq = (rand(1) * BW);
        end        
        index = find(start_freq <= Avail_Spectrum + guard_band);
        %Calculate maximum frequency
        if ~isempty(index)            
            max_freq = min(Avail_Spectrum(index) - guard_band - start_freq);
        else
            max_freq = (BW - start_freq);
        end
    end
    %Calculate stop_frequency
    stop_freq = start_freq + rand(1) * max_freq;    
    if ~isempty(Avail_Spectrum)
        while(1)
            index = find(stop_freq >= Avail_Spectrum(:,1) - guard_band & stop_freq <= Avail_Spectrum(:,2) + guard_band);
            if isempty(index)
                break;
            end
            stop_freq = start_freq + rand(1) * max_freq; 
        end  
    end
    
    Avail_Spectrum = [Avail_Spectrum; start_freq, stop_freq];
end

Avail_Spectrum = Avail_Spectrum - (BW / 2);