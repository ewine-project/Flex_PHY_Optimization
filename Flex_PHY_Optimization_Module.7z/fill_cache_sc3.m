clear;
close all;

% Add all libraries
if ~isdeployed 
    addpath(genpath(cd))
end

% show plots
PLOT = 1

% use caching from disk to speed up computation
do_caching = 1;
num_cache_hits = 0;
num_cache_miss = 0;

if do_caching
    try
        load('opt_cache.mat')
    catch stmt
        opt_cache = containers.Map();
        save('opt_cache.mat','opt_cache');
    end
else
    % GFDM cache
    opt_cache = containers.Map();    
end

% Initialize TestMan
type = 10;  %application type/class
id = 1;     %application instance number

n = 4;
M = dec2bin(0:(2^n)-1)-'0';

for ii=1:size(M,1)
    v = M(ii,:);
    
    spectrum_mask = [];
    for jj=1:size(v,2)
        if (v(jj) == 1)
            f_center = -30e6 + (jj-1)*20e6;
            fstart = f_center - 10e6;
            fstop = f_center + 10e6;
            spectrum_mask = [spectrum_mask fstart fstop];
            
        end
    end

    % remove nulls
    del_idx = [];
    for ii=1:size(spectrum_mask,2)-1
        if spectrum_mask(ii) == spectrum_mask(ii+1)
            del_idx = [del_idx; ii];
            del_idx = [del_idx; ii+1];
        end
    end
    
    if ~isempty(del_idx)
       spectrum_mask(del_idx) = [];
    end
    
    %disp('Spectrum mask');
    %spectrum_mask
    
    if ~isempty(spectrum_mask)
        spectrum_mask = reshape(spectrum_mask, [2, numel(spectrum_mask)/2])'
    end
    
    % Initialize variables
    BW             = 80*1e6;
    Guard_BW       = 5*1e4;  
    subcarriers = 64;
    subsymbols = 9;

    %Who receives the results?
    receive_type = 11;
    receive_id = 1;

    cache_key.bw = BW;
    cache_key.subcarriers = subcarriers;
    cache_key.subsymbols = subsymbols;
    cache_key.Guard_BW = Guard_BW;
    cache_key.spectrum_mask = spectrum_mask;
    Opt.Method = 'SHA-1';

    hash_val = DataHash(cache_key, Opt);
    
    hash_val

    if opt_cache.isKey(hash_val)
       % from cache
       disp('Cache hit');
       num_cache_hits = num_cache_hits + 1;
       res = opt_cache(hash_val);
       gfdm = res.gfdm;
       ofdm = res.ofdm;
       
       if (PLOT)
            %figure(100);
            hFig = figure(100);
            set(hFig, 'Position', [100 100 700 275])

            clf;
            plot(gfdm.pl_x, gfdm.pl_y,'r');
            hold on
            plot(ofdm.pl_x, ofdm.pl_y,'b');
            plot(gfdm.pl_mask_x, gfdm.pl_mask_y, 'k','LineWidth',3);
            ylim([-200 10]);
            BW = gfdm.Sampfreq;
            xlim(0.6*[-BW BW]./1e6);
            legend('PSD of GFDM','PSD of OFDM','Ideal Spectrum Mask');
            xlabel('Freq (MHz)');
            ylabel('PSD (dB)');
            legend('Location','southwest');
            hold off;                   
       end       
    else           
       disp('Cache miss');
       disp('Calculate GFDM parameter...');
       num_cache_miss = num_cache_miss + 1;

       tic
       [gfdm,ofdm] = config_gfdm_dynamic_spectrum_access(BW, spectrum_mask, Guard_BW, subcarriers, subsymbols);
       toc
     
       res.gfdm = gfdm;
       res.ofdm = ofdm;

       opt_cache(hash_val) = res;
       save('opt_cache.mat','opt_cache');
       pause(1);
    end
end
 
num_cache_hit_ratio = num_cache_hits / (num_cache_miss + num_cache_hits)

disp('num_cache_hit_ratio');
num_cache_hit_ratio